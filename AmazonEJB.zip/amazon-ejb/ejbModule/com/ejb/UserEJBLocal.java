package com.ejb;

import javax.ejb.Local;

@Local
public interface UserEJBLocal {

}
